#include <stdio.h>

int main () {
	
	char A = 'a';
	
	printf("A = %c\n", A);
	
	return 0;
}

#include <stdio.h>
#define PI 3.141519

int main () {
	
	double R = 10.0;
	
	double A = PI * R * R;
	
	printf("Area = %f\n", A);
	
	return 0;
}

#include <stdio.h>

int main(){
	int a = 1;
	
	do {
		printf("\nUSCS");
		a = a + 1;
	} while(a < 5);
}

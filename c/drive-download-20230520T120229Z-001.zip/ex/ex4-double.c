#include <stdio.h>

int main () {
	
	float X = 5.0F;
	
	float Y = 7.005F;
	
	float Z = X + Y;
	
	printf("Z = %f\n", Z);
	
	return 0;
}

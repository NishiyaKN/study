#include <stdio.h>
int main (){
	char entrada;
	printf("Entre com um caractere qualqeur: \n");
	scanf("%c",&entrada);
	printf("O caractere entrado foi: %c\n",entrada);
	return 0;
}

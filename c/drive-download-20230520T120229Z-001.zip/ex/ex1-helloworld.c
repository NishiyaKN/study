#include <stdio.h>

int main () {
	int A = 10;
	int B = 20;
	int C = A + B;
	
	printf("C= %i", C);
	
	return 0;
}

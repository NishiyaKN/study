#include <stdio.h>


int main () {
	
	int A = 10;
	float B = 5.8;
	double C = 5.97;
	char X = 'x';
	
	printf ("USCS - Computacao\n\n");
	printf ("%d%c%f%s",40,'a',3.45,"Hello World...\n\n");
	printf ("Um caractere %c e um inteiro %d\n\n",X,A);
	printf ("Um float %f e um double %f\n\n",B,C);
}

#include <stdio.h>

int main () {
	
	double X = 1.0000001;
	
	double Y = 7.0;
	
	double Z = X + Y;
	
	printf("A = %f\n", Z);
	
	return 0;
}

#include <stdio.h>

int main () {
	int C = 0;
	int S = 10;
	
		while (C < 5)
		C++;
	
		S = S+C;
		
		printf("O valor de S e: %d",S);
		return 0;	
}

#include <stdio.h>

int main() {
	int X=10, Y=20, Z;
	
	++X;
	++Y;
	Z = X + Y;
	
	printf("Z= %d", Z);
}

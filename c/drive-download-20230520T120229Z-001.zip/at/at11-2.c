#include <stdio.h>
int main(){
	int lado;
	printf("Entre com o lado: ");
	scanf("%d",&lado);
	
	printf("Lado: %d\nArea: %d\n",lado,lado*lado);
	
	return 0;
}

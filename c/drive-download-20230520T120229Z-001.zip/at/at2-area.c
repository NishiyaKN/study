#include <stdio.h>

int main(){
		
	int lado;
	
	printf("Digite o tamanho do lado de um quadrado \n");
	
	scanf("%d", &lado);
	
	int a = lado*lado;
	
	printf("A area eh: %d",a);
	
	return 0;
	
}
